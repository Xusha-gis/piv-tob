📘 Bu bot foydalanuvchilardan Click chekini rasm yoki PDF ko‘rinishda qabul qiladi.
Faylni ishga tushiring: `python main.py`
