
import os

BOT_TOKEN = os.getenv("BOT_TOKEN", "8188119649:AAEC5lTlyPTTskGxO_d5APGKXE8iKmZKwbo")
CHANNEL_LINK = os.getenv("CHANNEL_LINK", "https://t.me/+tz7C4K2sDElmYjky")
ADMIN_ID = int(os.getenv("ADMIN_ID", "123456789"))
